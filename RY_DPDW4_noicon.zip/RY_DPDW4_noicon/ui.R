#
# This is the user-interface definition of a Shiny web application. You can
# run the application by clicking 'Run App' above.
#
# Find out more about building applications with Shiny here:
#
#    http://shiny.rstudio.com/
#

library(shiny)
library(leaflet)

# Define UI for application that draws a histogram
shinyUI(fluidPage(
    
    # Application title
    titlePanel("Chicago Inspection Predictor"),
    h4("Created By Rongbin Ye for JHU Data Product Development course."),
    h5("This model requires time for loading and runing after submitting."),
    # Sidebar with a slider input for number of bins
    sidebarLayout(
        sidebarPanel(
            sliderInput("lat",
                        "Latitude:",
                        min = 41.6481,
                        max = 42.0209,
                        step = .001,
                        value = 41.7000
            ),
            sliderInput("lng",
                        "Longtitude:",
                        min = -87.9144,
                        max = -87.5251,
                        step = .001,
                        value = -87.7500
            ),
            selectInput("FType","Choose a Facility Type:",
                        list('restaurant', 'school', 'bakery', 'catering')
            ),
            selectInput("RType", "Choose a Risk Type:", list("risk 1 (high)","risk 2 (medium)","risk 3 (low)")
            ),
            checkboxInput("Showp","Show the Summary", TRUE
            ),
            submitButton("Submit")
        ),
        # Show a plot of the generated distribution
        mainPanel(
            h3("The Location of ideal location"),
            leafletOutput("Map_Locator"),
            h3("The Model Summary"),
            textOutput("Show_summary"),
            h3("The Predicted Result"),
            textOutput("Predicted_Result")
        )
    )
)
)